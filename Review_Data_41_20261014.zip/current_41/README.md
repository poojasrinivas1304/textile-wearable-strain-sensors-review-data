# Textile wearable strain sensors: current review data

## Cohorts

- The current synthesis contains **41 studies**.
- Historical independent readiness/reporting agreement uses the **39 retained paired studies**, not all 41.
- Eligibility agreement uses the original **42 candidates**.

All 82 readiness ratings and 369 reporting scores have reviewer approval. The 656-item methodological-reporting matrix comprises 114 explicitly confirmed decisions and 542 retained Reviewer 2 assessments. This is not a new complete paired independent risk-of-bias assessment. Original independent ratings remain separate from adjudicated values.

The 14 October 2026 consolidation incorporates four quality revisions: Liu (2019), Q10 = 1; Zhou (2022), Kumar (2023) and Aliyana (2024), Q6 = 2. Tavassolian and Raiano Q16 = 0 were confirmed after checking their supplements.

## Files and reproduction

`Supplementary_Data_41_20261014.xlsx` contains the study inventory, extraction, rubric, original ratings, adjudications, counts and recorded exclusions. The companion PDF presents Supplementary Tables S1–S13. Files retain missingness, source-conflict and verification status labels.

Install dependencies with `python -m pip install -r requirements.txt`, then run from this folder:

```sh
python calculate_kappa.py --data data/independent_ratings.csv
python draw_figures.py
```

`data/independent_ratings.csv` contains only original independent ratings, not consensus scores. Readiness levels 1–5 are encoded 0–4 in this CSV; this shift does not change quadratic-weighted kappa. The code preserves archived source-table study order, uses 10,000 study-cluster bootstrap resamples per metric with seed 2026 and omits undefined estimates. The two added studies do not enter the agreement calculation.

Expected pooled results:

| Assessment | Paired studies | Kappa | 95% bootstrap interval |
| --- | ---: | ---: | --- |
| Eligibility |42|0.787879|0–1|
| Readiness axes |39|0.772385|0.604287–0.897773|
| Reporting items |39|0.718120|0.630941–0.798300|

`data/analysis41.json` supplies current study labels, confirmed figure scores, categories and counts. `draw_figures.py` regenerates quantitative Figures 2, 4, 5 and 6 in `generated_figures/`. The supplied figures preserve the review's chosen layout. No copyrighted article PDFs or raw reviewer workbooks are included.

## Interpretation limits

These distributions describe the selected studies, not field-wide prevalence or growth. Five active constructions remain undetermined. Unresolved extraction fields are not pooled into performance rankings. The current archived flow contains 834 eligibility dispositions, 793 recorded exclusions, 3 unretrieved reports and 41 included studies. Reconciled arithmetic does not establish complete independent verification of every archived exclusion. In the ledger, 790 exclusions retain pending verification labels; these labels do not by themselves prove that no initial assessment occurred.

The focused eligibility refinement was retrospective. Quality scores assess reporting completeness, not demonstrated rigor, clinical effectiveness or low risk of bias. Review-specific readiness categories do not establish regulatory approval or commercial readiness.

Legacy 29-study files belong to an earlier version and must not be used to reproduce the current 41-study synthesis or 39-study independent agreement.
