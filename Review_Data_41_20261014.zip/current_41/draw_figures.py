"""Reproducible Figure 5/6 plots from confirmed scores; source workbook is read-only."""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np


ROOT=Path(__file__).resolve().parent
BASE=ROOT
BUILD=ROOT/'data'
OUT=ROOT/'generated_figures'
OUT.mkdir(parents=True,exist_ok=True)
SOURCE=ROOT/'Supplementary_Data_41_20261014.xlsx'
source_hash=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
d=json.loads((BUILD/'analysis41.json').read_text())
labels_by_id={r[1]:r[7] for r in d['studies']}
codes=['F1','F2','E1','E2','E3','E4','R1','V1','V2']
f5={}
f6={}
for row in d['readiness']:
    rec=f5.setdefault(row[0],{'study':labels_by_id[row[0]]});rec[row[2]]=int(row[6])
for row in d['reporting']:
    rec=f6.setdefault(row[0],{'study':labels_by_id[row[0]]});rec[row[2]]=int(row[6])
assert len(f5)==len(f6)==41 and set(f5)==set(f6)

palette = {2: '#6EA6CF', 1: '#F2B760', 0: '#D97B63'}
edges = {2: '#477DA4', 1: '#B27B31', 0: '#9E503D'}
sizes = {2: 10, 1: 18, 0: 27}
ink = '#20262C'
plt.rcParams.update({
    'font.family': 'Arial', 'font.size': 7.5,
    'axes.labelsize': 8.5, 'axes.labelweight': 'bold',
    'axes.titlesize': 8, 'axes.titleweight': 'bold',
    'axes.linewidth': .6, 'xtick.major.width': .5,
    'ytick.major.width': .5, 'svg.fonttype': 'none',
    'pdf.fonttype': 42, 'figure.facecolor': 'white',
    'savefig.facecolor': 'white', 'text.color': ink,
    'axes.labelcolor': ink, 'xtick.color': ink, 'ytick.color': ink,
})

def save(fig, name):
    # Identical bounded canvas in all formats: no tight-crop rescaling.
    for extension in ['pdf', 'svg', 'png']:
        kwargs = {'dpi': 600} if extension == 'png' else {}
        fig.savefig(OUT / (name + '.' + extension), **kwargs)
    fig.savefig(BUILD / (name + '_preview.png'), dpi=180)
    plt.close(fig)

# Figure 5: data points remain on the exact ordinal levels, without jitter.
cells = Counter((r['VD'], r['DR']) for r in f5.values())
fig = plt.figure(figsize=(7.2, 5.25))
ax = fig.add_axes([.218, .215, .763, .756])
ax.set_facecolor('#FBFCFE')
ax.add_patch(Rectangle((3.5, 3.5), 2, 2, facecolor='#EAF5EC', edgecolor='none', zorder=0))
ax.text(5.40, 5.34, 'Higher-maturity region', ha='right', va='top',
        fontsize=8, fontweight='bold', color='#2F6F44')
for (vd, dr), count in sorted(cells.items()):
    # True area proportionality, unlike the historical area-plus-offset code.
    ax.scatter(vd, dr, s=count * 72, color='#589FD0', edgecolor='#173F5F',
               linewidth=.85, zorder=3)
    ax.text(vd, dr, str(count), ha='center', va='center', fontsize=8.5,
            fontweight='bold', color='#102A43', zorder=4)
ax.set(xlim=(.5, 5.5), ylim=(.5, 5.5))
ax.set_xticks(range(1, 6), [
    '1\nProof of\nconcept', '2\nOn-body\ndemonstration',
    '3\nTask-level\nvalidation', '4\nStructured\nevaluation',
    '5\nNear-deployment\nevidence'])
ax.set_yticks(range(1, 6), [
    '1  Material or\nswatch', '2  Textile-integrated\nprototype',
    '3  On-body\nprototype', '4  Garment-level\nprototype',
    '5  Advanced\nwearable system'])
ax.set_xlabel('Validation depth', labelpad=9)
ax.set_ylabel('Deployment readiness', labelpad=9)
ax.grid(color='#B8C2CC', alpha=.55, linewidth=.55)
ax.set_axisbelow(True)
for spine in ax.spines.values():
    spine.set_color('#25313C')
    spine.set_linewidth(.75)
ax.tick_params(axis='both', length=3, pad=4, labelsize=7.5)
ax.text(.978, .025, '$n$ = 41 studies', transform=ax.transAxes,
        ha='right', va='bottom', fontsize=7.5, color='#576675')
fig.text(.218, .034, 'Bubble area and numbers represent study counts.', fontsize=7)
save(fig, 'Figure5')

# Figure 6: chronology followed by author gives reproducible, unambiguous labels.
order = sorted(f6, key=lambda rid: (int(re.search(r'\((\d{4})\)', f6[rid]['study']).group(1)), f6[rid]['study'], rid))
labels = [f6[rid]['study'].replace(' et al.', '').replace('(', '').replace(')', '') + (' *' if rid in ['REC-00001','REC-00009'] else '') for rid in order]
assert len(set(labels)) == 41
matrix = np.array([[f6[rid][code] for code in codes] for rid in order])
counts = {code: Counter(matrix[:, index]) for index, code in enumerate(codes)}
assert matrix.shape == (41, 9) and all(sum(v.values()) == 41 for v in counts.values())

fig = plt.figure(figsize=(7.2, 7.25))
ax = fig.add_axes([.160, .077, .452, .800])
ax_b = fig.add_axes([.687, .581, .292, .296])
ax_leg = fig.add_axes([.681, .375, .303, .145])
ax_defs = fig.add_axes([.681, .100, .303, .225])
ax.set(xlim=(-.5, 8.5), ylim=(40.5, -.5))
ax.set_xticks(range(9), codes, fontsize=7, fontweight='bold')
ax.set_yticks(range(41), labels, fontsize=6.6)
ax.set_xlabel('Reporting item', labelpad=7, fontsize=8)
ax.set_ylabel('Included studies', labelpad=7, fontsize=8)
ax.set_title('Study-level reporting evidence map', y=1.112, pad=0, fontsize=8)
ax.set_xticks(np.arange(-.5, 9, 1), minor=True)
ax.set_yticks(np.arange(-.5, 41, 1), minor=True)
ax.grid(which='minor', color='#DADDE0', linewidth=.35)
ax.tick_params(which='both', length=0)
ax.tick_params(axis='y', pad=3)
for spine in ax.spines.values():
    spine.set_color('#333333')
    spine.set_linewidth(.6)
for divider in [1.5, 5.5, 6.5]:
    ax.axvline(divider, color='#4A4A4A', linewidth=.75, zorder=2)
for yy in range(41):
    for xx in range(9):
        score = int(matrix[yy, xx])
        ax.scatter(xx, yy, s=sizes[score], c=palette[score], edgecolors=edges[score],
                   linewidth=.4, zorder=3)

def bracket(left, right, label, color):
    y = 1.018
    ax.plot([left, left, right, right], [y, y + .014, y + .014, y],
            transform=ax.get_xaxis_transform(), clip_on=False, color=color, linewidth=1)
    ax.text((left + right) / 2, y + .025, label,
            transform=ax.get_xaxis_transform(), ha='center', va='bottom',
            fontsize=6.2, fontweight='bold', color=color)
bracket(-.45, 1.45, 'Fabrication', '#B54D91')
bracket(1.55, 5.45, 'Electromechanical', '#3C8CA3')
bracket(5.55, 6.45, 'Environ.', '#3D964D')
bracket(6.55, 8.45, 'Validation', '#865AB7')

left = np.zeros(9)
for score in [2, 1, 0]:
    values = np.array([counts[code][score] / 41 * 100 for code in codes])
    ax_b.barh(range(9), values, left=left, height=.66, color=palette[score],
              edgecolor='white', linewidth=.25)
    left += values
assert np.allclose(left, 100)
for index, code in enumerate(codes):
    pct = counts[code][2] / 41 * 100
    if pct >= 8:
        ax_b.text(pct / 2, index, f'{pct:.1f}', ha='center', va='center', fontsize=6.1)
ax_b.set_yticks(range(9), codes, fontsize=6.8)
ax_b.set(xlim=(0, 100), ylim=(8.6, -.6))
ax_b.set_xticks(range(0, 101, 20))
ax_b.tick_params(axis='x', labelsize=6.2, length=2.5)
ax_b.tick_params(axis='y', length=0, pad=3)
ax_b.set_xlabel('All 41 studies (%)', fontsize=7, labelpad=5)
ax_b.set_title('Reporting status by item', fontsize=8, pad=10)
ax_b.grid(axis='x', color='#DADDE0', linewidth=.35)
ax_b.set_axisbelow(True)
ax_b.spines[['top', 'right']].set_visible(False)

ax_leg.axis('off')
handles = [Line2D([0], [0], marker='o', linestyle='', markersize=np.sqrt(sizes[score]),
          markerfacecolor=palette[score], markeredgecolor=edges[score], markeredgewidth=.45,
          label=label) for score, label in [
              (2, '2  Clearly reported'), (1, '1  Partly reported'), (0, '0  Not reported')]]
ax_leg.legend(handles=handles, loc='upper left', frameon=False, fontsize=7,
              handletextpad=.6, labelspacing=.75, borderaxespad=0)
ax_leg.text(.018, .05, 'Bar labels: score-2 percentages.\n* Added study; ratings confirmed. No NA.',
            va='bottom', fontsize=6.6, linespacing=1.5)

definitions = [
    'F1  Architecture / integration', 'F2  Material / substrate composition',
    'E1  Working strain range', 'E2  Gauge factor and strain interval',
    'E3  Signal-quality descriptors', 'E4  Dynamic / durability descriptors',
    'R1  Environmental robustness', 'V1  On-body / garment reporting',
    'V2  Comparator validation']
ax_defs.axis('off')
ax_defs.text(.018, 1, '\n'.join(definitions), va='top', fontsize=6.6, linespacing=1.7)
fig.text(.020, .965, 'a', fontsize=11, fontweight='bold')
fig.text(.648, .965, 'b', fontsize=11, fontweight='bold')
save(fig, 'Figure6')

caption5 = ('Figure 5. Validation depth and deployment readiness of the 41 included studies. '
    'Each study is positioned using the approved rubric on both ordinal axes. '
    'Bubble area is proportional to the number of studies at each position, and numbers show study counts. '
    'The shaded higher-maturity region comprises validation-depth levels 4-5 and deployment-readiness levels 4-5. '
    'The ratings summarize the reported evidence and system integration under the review-specific rubric; '
    'they do not establish clinical effectiveness, regulatory approval or commercial readiness. '
    'All82axis ratings are confirmed. The original39-study independent ratings remain separate from adjudication.')
caption6 = ('Figure 6. Reporting completeness across the 41 included studies. '
    '(a) Analysis scores for nine reporting items in each study, ordered by publication year and then author. '
    'Blue, amber and red dots denote scores of 2 (clearly reported), 1 (partly reported) and 0 (not reported), respectively, '
    'according to the item-specific rubric. Dot size distinguishes these categories and does not represent a numerical quantity. '
    '(b) Distribution of scores for each item. Percentages use all 41 studies as the denominator; '
    'numbers within blue bar segments show the score-2 percentages to one decimal place. '
    'All369scores are confirmed. No unscored or not-applicable analysis values. '
    'E3 covers signal-quality descriptors, while E4 covers dynamic response or cyclic durability; a score of 2 does not imply '
    'that every descriptor within a combined item was reported. The framework primarily assesses reporting completeness, '
    'not independently established methodological rigor.')

summary = {
    'source_workbook': str(SOURCE), 'source_sha256': source_hash,
    'source_columns': {'S3 readiness scores':'G (Analysis score)','S5 reporting scores':'G (Analysis score)'},
    'included_studies': 41, 'figure5_confirmed_axis_ratings':82,'figure5_added_author_ratings':0,
    'figure6_confirmed_item_scores':369,'figure6_added_author_scores':0, 'pending': 0, 'not_applicable': 0,
    'figure5_cells': [{'VD': vd, 'DR': dr, 'count': n} for (vd, dr), n in sorted(cells.items())],
    'figure5_VD_counts': dict(sorted(Counter(r['VD'] for r in f5.values()).items())),
    'figure5_DR_counts': dict(sorted(Counter(r['DR'] for r in f5.values()).items())),
    'figure5_higher_maturity_region_n': sum(n for (vd, dr), n in cells.items() if vd >= 4 and dr >= 4),
    'figure6_counts': {c: {str(s): int(counts[c][s]) for s in [0, 1, 2]} for c in codes},
    'figure6_percentages': {c: {str(s): counts[c][s] / 41 * 100 for s in [0, 1, 2]} for c in codes},
    'caption_figure5': caption5, 'caption_figure6': caption6,
    'files': [str(OUT / (stem + '.' + ext)) for stem in ['Figure5', 'Figure6'] for ext in ['pdf', 'svg', 'png']],
    'checks': {'original_workbook_unchanged': hashlib.sha256(SOURCE.read_bytes()).hexdigest() == source_hash,
               'all_41_ids_match_between_figures': set(f5) == set(f6),
               'all_bars_sum_to_100_percent': bool(np.allclose(left, 100)),
               'tan_confirmed_E2_E3': [f6['REC-01371']['E2'], f6['REC-01371']['E3']]},
}
(BUILD / 'figure_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
with (BUILD / 'confirmed_figure_source_data.csv').open('w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['Record ID', 'Study', 'VD', 'DR', *codes])
    writer.writerows([rid, f6[rid]['study'], f5[rid]['VD'], f5[rid]['DR'], *[f6[rid][c] for c in codes]] for rid in order)
print(json.dumps(summary, indent=2))

# Cohort overview retains publication-year and category panels.
years=Counter(r[4] for r in d['studies']);arch=Counter(r[5] for r in d['categories']);mechanism=Counter(r[9] for r in d['categories'])
appnames=['Movement/posture/gait','Respiration','Pulse/heartbeat','Speech/swallowing/facial','Robotic-hand/HMI','Muscle contraction/force','Model-derived fatigue']
appcols=[25,28,27,30,29,26,24];apps=[sum(r[c] for r in d['categories']) for c in appcols]
fig,axs=plt.subplots(2,2,figsize=(7.2,5.9));fig.subplots_adjust(left=.09,right=.98,top=.94,bottom=.08,wspace=.65,hspace=.6)
axs[0,0].bar(range(2015,2027),[years[y] for y in range(2015,2027)],color='#6EA6CF');axs[0,0].set_xticks(range(2016,2027,2));axs[0,0].set_ylabel('Studies');axs[0,0].set_title('a  Publication year');axs[0,0].set_yticks(range(0,9,2))
archlabels=['Knitted','Fibre/yarn/thread','Construction undetermined','Woven','Discrete/composite on garment','Embroidery/stitch','Nonwoven/electrospun'];archkeys=['Knitted sensing textile','Fibre/yarn/thread sensing element','Sensing fabric construction not determined','Woven sensing textile','Discrete/composite sensor mounted on garment','Embroidery/stitch-based sensing structure','Nonwoven/electrospun sensing mat']
axs[0,1].barh(range(7),[arch[k] for k in archkeys],color='#6EA6CF');axs[0,1].set_yticks(range(7),archlabels,fontsize=6.7);axs[0,1].invert_yaxis();axs[0,1].set_xlabel('Studies');axs[0,1].set_title('b  Active sensing architecture')
axs[1,0].barh(['Resistive','Capacitive','Inductive'],[mechanism[k] for k in ['Resistive','Capacitive','Inductive']],color=['#6EA6CF','#F2B760','#D97B63']);axs[1,0].invert_yaxis();axs[1,0].set_xlabel('Studies');axs[1,0].set_title('c  Sensing mechanism')
axs[1,1].barh(range(7),apps,color='#6EA6CF');axs[1,1].set_yticks(range(7),appnames,fontsize=6.7);axs[1,1].invert_yaxis();axs[1,1].set_xlabel('Studies (overlapping)');axs[1,1].set_title('d  Demonstrated human applications')
for ax in axs.flat:ax.spines[['top','right']].set_visible(False)
save(fig,'Figure2')
# Separate quality reporting profile. No unvalidated pooled quality total.
qcodes=['Q'+str(i) for i in range(1,17)];qcounts=d['counts']['quality'];qlabels=['Fabricated samples','Manufacturing batches','Complete devices','Participants','Repeated sessions','Calibration','External reference','Statistical uncertainty','Testing conditions','Device reproducibility','Environmental protocol','Stability/failure criteria','Inter-user transfer','Fit/placement/pretension','Electronics/power','Data/code availability']
fig,ax=plt.subplots(figsize=(7.2,5.65));fig.subplots_adjust(left=.33,right=.97,top=.91,bottom=.12);l=np.zeros(16)
for s0 in [2,1,0]:
    a=np.array([qcounts[c][s0]/41*100 for c in qcodes]);ax.barh(range(16),a,left=l,color=palette[s0],edgecolor='white',linewidth=.3);l+=a
ax.set_yticks(range(16),qlabels,fontsize=7);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xlabel('All 41 studies (%)');ax.set_title('Methodological reporting by domain');ax.grid(axis='x',linewidth=.3,color='#cccccc');ax.set_axisbelow(True);ax.spines[['top','right']].set_visible(False)
ax.legend([Rectangle((0,0),1,1,facecolor=palette[s]) for s in [2,1,0]],['2 Clearly described','1 Partly described','0 No assessable reporting'],loc='upper center',bbox_to_anchor=(.5,1.13),ncol=3,frameon=False,fontsize=6.7)
save(fig,'Figure4')
print('Additional figures2 and4 generated;41-study denominators verified.')
