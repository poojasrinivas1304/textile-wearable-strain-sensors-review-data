from pathlib import Path
import json
BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'generated_figures'
OUT.mkdir(exist_ok=True)
DATA=json.loads((BASE/'data/analysis41.json').read_text())
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

assert sorted(r[2] for r in DATA['category_counts'] if r[0]=='Architecture')==[2,3,4,4,5,10,13]
BLUE='#447DA6'; BLUEF='#A9CBE1'; TEAL='#39978C'; TEALF='#A1D1C7'; ORANGE='#D9845D'; GREY='#A6AFB6'; INK='#20262B'
plt.rcParams.update({'font.family':'Arial','font.size':8,'text.color':INK,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,'axes.linewidth':.6,'svg.fonttype':'none'})
fig=plt.figure(figsize=(9.2,6),facecolor='white')
# The two panel columns share a compact, fixed gutter. Category labels sit
# inside each panel's allocated column rather than widening the gutter.
def panel(x,y,letter,title):
    fig.text(x,y,letter,fontsize=11,fontweight='bold',va='baseline')
    fig.text(x+.025,y,title,fontsize=9,va='baseline')
def base(ax):
    for s in ['top','right']:ax.spines[s].set_visible(False)
    for s in ['bottom','left']:ax.spines[s].set_color('#59636C')
    ax.tick_params(length=3,width=.6,labelsize=7)
    ax.set_axisbelow(True)
panel(.065,.947,'a','Publication year')
panel(.535,.947,'b','Active sensing construction')
panel(.065,.455,'c','Sensing mechanism')
panel(.535,.455,'d','Human applications')

ax=fig.add_axes([.085,.595,.37,.29]); base(ax)
years=np.array([r[0] for r in DATA['publication_years']]); counts=[r[1] for r in DATA['publication_years']]
bars=ax.bar(years,counts,width=.64,color=BLUEF,edgecolor=BLUE,linewidth=.65)
for xx,v in zip(years,counts):
    if v: ax.text(xx,v+.18,str(v),ha='center',fontsize=7)
ax.set(xlim=(2014.4,2026.6),ylim=(0,8),ylabel='Studies')
ax.set_xticks(years); ax.tick_params(axis='x',rotation=45); ax.set_yticks([0,2,4,6,8])
ax.grid(axis='y',lw=.4,color='#E1E6EA')

def categories(ax,names,values,color,fill,xmax,ticks,mode='bar',special=None):
    base(ax); y=np.arange(len(names))
    if mode=='bar':
        colors=[GREY if i==special else fill for i in y]
        edges=[GREY if i==special else color for i in y]
        ax.barh(y,values,height=.54,color=colors,edgecolor=edges,linewidth=.6,zorder=2)
    else:
        ax.hlines(y,0,values,color='#BFD9D4',lw=1.2,zorder=2)
        ax.scatter(values,y,s=22,color=fill,edgecolor=color,linewidth=.8,zorder=3)
    for yy,v in zip(y,values): ax.text(v+xmax*.035,yy,str(v),va='center',fontsize=7)
    ax.set_ylim(len(names)-.45,-.65); ax.set_xlim(0,xmax); ax.set_yticks([])
    ax.set_xticks(ticks); ax.set_xlabel('Studies',fontsize=8,labelpad=5)
    ax.spines['left'].set_visible(False)
    ax.grid(axis='x',color='#E6EAED',lw=.4)
    # Fixed figure-coordinate labels avoid creating a large inter-panel gap.
    for yy,name in zip(y,names):
        ax.text(-.045,yy,name,transform=ax.get_yaxis_transform(),ha='right',va='center',fontsize=7,clip_on=False)

ax=fig.add_axes([.697,.573,.262,.312])
categories(ax,['Knitted','Fibre/yarn/thread','Undetermined','Woven','Mounted composite','Embroidery/stitch','Nonwoven'],[13,10,5,4,4,3,2],BLUE,BLUEF,15,[0,5,10,15],special=2)

ax=fig.add_axes([.19,.115,.265,.28])
categories(ax,['Resistive','Capacitive','Inductive'],[33,7,1],ORANGE,'#F0CFBD',38,[0,10,20,30])

ax=fig.add_axes([.715,.105,.244,.29])
categories(ax,['Movement/posture/gait','Respiration','Speech/swallow/facial','Pulse','HMI/robotic hand','Muscle','Fatigue model'],[36,13,10,8,3,2,1],TEAL,TEALF,41,[0,10,20,30,40],mode='dot')

fig.savefig(OUT/'Figure2.png',dpi=350,facecolor='white')
fig.savefig(OUT/'Figure2.svg',facecolor='white')
