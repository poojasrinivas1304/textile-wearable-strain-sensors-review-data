from pathlib import Path
import json
BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'generated_figures'
OUT.mkdir(exist_ok=True)
DATA=json.loads((BASE/'data/analysis41.json').read_text())
from pathlib import Path
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch,Rectangle

text=(BASE/'Supplementary_Information.tex').read_text().split('\\subsection*{Supplementary Table S7.')[1].split('\\end{longtable}')[0]
pairs=re.findall(r' & ([1-5]) & ([1-5]) & Confirmed',text)
assert len(pairs)==41
m=np.zeros((4,3),dtype=int)
for v,d in pairs:m[5-int(d),{2:0,4:1,5:2}[int(v)]]+=1
assert m.sum()==41
colors=['#447DA6','#39978C','#DC895F']
plt.rcParams.update({'font.family':'Arial','font.size':9,'text.color':'#27343D','svg.fonttype':'none'})
fig=plt.figure(figsize=(9.5,5.5),facecolor='white');ax=fig.add_axes([.025,.055,.95,.87]);ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
xl=.31;xr=.70;w=.013;scale=.018;gap=.035
lefttot=m.sum(axis=1);righttot=m.sum(axis=0)
lefttop=[];y=.88
for n in lefttot:lefttop.append(y);y-=n*scale+gap
righttop=[];y=.88
for n in righttot:righttop.append(y);y-=n*scale+gap
ax.text(xl,.96,'Integration maturity',ha='right',fontsize=11,fontweight='bold')
ax.text(xr,.96,'Validation depth',ha='left',fontsize=11,fontweight='bold')
leftnames=['Advanced wearable\nsystem','Garment-level\nprototype','On-body\nprototype','Textile-integrated\nprototype']
rightnames=['Illustrative on-body\ndemonstration','Structured human\nevaluation','Structured human evaluation\nwith robustness testing']
lo=lefttop.copy();ro=righttop.copy()
for i in range(4):
    for j in range(3):
        n=m[i,j]
        if not n:continue
        h=n*scale;ytl=lo[i];ytr=ro[j];lo[i]-=h;ro[j]-=h
        x0=xl+w;x1=xr;dx=(x1-x0)*.43
        vertices=[(x0,ytl),(x0+dx,ytl),(x1-dx,ytr),(x1,ytr),(x1,ytr-h),(x1-dx,ytr-h),(x0+dx,ytl-h),(x0,ytl-h),(x0,ytl)]
        codes=[MPath.MOVETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4,MPath.LINETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4,MPath.CLOSEPOLY]
        ax.add_patch(PathPatch(MPath(vertices,codes),facecolor=colors[j],alpha=.38,edgecolor='white',lw=.5))
        # Label each flow at its left endpoint, before any crossing.
        ax.text(x0+.017,ytl-h/2,str(n),ha='left',va='center',fontsize=8,color='#253846',zorder=5)
for i,(name,n) in enumerate(zip(leftnames,lefttot)):
    ax.add_patch(Rectangle((xl,lefttop[i]-n*scale),w,n*scale,facecolor='#879AA8',edgecolor='none'))
    ax.text(xl-.018,lefttop[i]-n*scale/2,f'{name}\n(n = {n})',ha='right',va='center',fontsize=9,linespacing=1.35)
for j,(name,n) in enumerate(zip(rightnames,righttot)):
    ax.add_patch(Rectangle((xr,righttop[j]-n*scale),w,n*scale,facecolor=colors[j],edgecolor='none'))
    ax.text(xr+w+.018,righttop[j]-n*scale/2,f'{name}\n(n = {n})',ha='left',va='center',fontsize=9,linespacing=1.35)
fig.savefig(OUT/'Figure5.png',dpi=330,facecolor='white')
fig.savefig(OUT/'Figure5.svg',facecolor='white')
