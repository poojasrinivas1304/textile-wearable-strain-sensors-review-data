from pathlib import Path
import json
BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'generated_figures'
OUT.mkdir(exist_ok=True)
DATA=json.loads((BASE/'data/analysis41.json').read_text())
from pathlib import Path
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

source=(BASE/'Supplementary_Information.tex').read_text().split('\\subsection*{Supplementary Table S9.')[1].split('\\end{longtable}')[0]
rows=[]
for line in source.splitlines():
    match=re.match(r'(.+?) et al\. \((\d{4})\) & ((?:[012U] & ){8}[012U])',line)
    if match:rows.append((match[1],int(match[2]),[-1 if v=='U' else int(v) for v in match[3].split(' & ')]))
assert len(rows)==41
order='Lorussi Wang Wu Ejupi Liu Massaroni Rezaei Vu Yu Eguchi Tavassolian Yang Yuan Zhao Lee Raiano Isaia Li Lu Wood Zhai Zhou Fu Kumar Sonil Aliyana Ayvaz Cao Romano Tang Zhou Liu Tan Zhang Bellisle Choi Ding Gai Galli Hassan Wang'.split()
ordered=[]
for name in order:
    candidates=[r for r in rows if r[0]==name]
    row=min(candidates,key=lambda r:r[1]);ordered.append(row);rows.remove(row)
data=np.array([r[2] for r in ordered]);assert data.shape==(41,9)
counts=np.array([(data==s).sum(axis=0) for s in [2,1,0,-1]])
assert np.array_equal(counts[0],[41,38,31,26,29,30,22,23,13])
assert counts[3].sum()==0 and counts[2,4]==4
plt.rcParams.update({'font.family':'Arial','font.size':8,'text.color':'#27343D','axes.labelcolor':'#27343D','xtick.color':'#27343D','ytick.color':'#27343D','svg.fonttype':'none'})
colors={2:'#447DA6',1:'#A1D1C7',0:'#DFE4E8',-1:'white'}
edges={2:'#376888',1:'#599F93',0:'#A9B5BE',-1:'#526F84'}
fig=plt.figure(figsize=(10.8,10.4),facecolor='white')
fig.text(.035,.963,'a',fontsize=12,fontweight='bold');fig.text(.10,.963,'Study-level reporting evidence map',fontsize=11)
fig.text(.665,.963,'b',fontsize=12,fontweight='bold')
ax=fig.add_axes([.17,.105,.435,.785])
for i in range(41):
    for j in range(9):ax.scatter(j,i,s=22,marker='s' if data[i,j]==-1 else 'o',facecolor=colors[data[i,j]],edgecolor=edges[data[i,j]],lw=.9 if data[i,j]==-1 else .6,zorder=3)
ax.set(xlim=(-.5,8.5),ylim=(40.5,-.5))
ax.set_xticks(range(9),['F1','F2','E1','E2','E3','E4','R1','V1','V2'])
ax.set_yticks(range(41),[f'{name} {year}'+(' *' if name in ['Yu','Lu'] else '') for name,year,_ in ordered])
ax.tick_params(length=0,labelsize=7,pad=5)
ax.set_xticks(np.arange(-.5,9,1),minor=True);ax.set_yticks(np.arange(-.5,41,1),minor=True)
ax.grid(which='minor',color='#E0E5E9',lw=.45);ax.tick_params(which='minor',length=0)
for x in [1.5,5.5,6.5]:ax.axvline(x,color='#8799A6',lw=.9)
for s in ax.spines.values():s.set_edgecolor('#8799A6');s.set_linewidth(.6)
for start,end,title in [(-.45,1.45,'Fabrication'),(1.55,5.45,'Electromechanical'),(5.55,6.45,'Environ.'),(6.55,8.45,'Validation')]:
    ax.plot([start,start,end,end],[-1.2,-1.65,-1.65,-1.2],clip_on=False,color='#7E95A6',lw=.7)
    ax.text((start+end)/2,-2.1,title,ha='center',va='bottom',fontsize=7,color='#526F84',clip_on=False)
ax.set_xlabel('Reporting item',fontsize=9,labelpad=8);ax.set_ylabel('Included studies',fontsize=9,labelpad=9)

ax=fig.add_axes([.69,.57,.285,.32]); y=np.arange(9);left=np.zeros(9)
for k,score in enumerate([2,1,0,-1]):
    val=counts[k]/41*100
    ax.barh(y,val,left=left,height=.67,color=colors[score],edgecolor=edges[-1] if score==-1 else 'white',hatch='////' if score==-1 else None,lw=.5);left+=val
for yy,p in enumerate(counts[0]/41*100):ax.text(p/2,yy,f'{p:.1f}',ha='center',va='center',fontsize=7,color='white')
ax.set_yticks(y,['F1','F2','E1','E2','E3','E4','R1','V1','V2']);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xticks([0,20,40,60,80,100]);ax.tick_params(length=3,width=.5,labelsize=7)
ax.set_title('Reporting status by item',fontsize=10,pad=12);ax.set_xlabel('Studies (%)',fontsize=8,labelpad=7)
for s in ['right','top','left']:ax.spines[s].set_visible(False)
ax.spines['bottom'].set_linewidth(.6);ax.spines['bottom'].set_color('#8799A6')
ax.grid(axis='x',color='#E0E5E9',lw=.45);ax.set_axisbelow(True)
handles=[Line2D([],[],marker='o',linestyle='none',markersize=5,markerfacecolor=colors[s],markeredgecolor=edges[s],label=label) for s,label in [(2,'2  Sufficiently explicit'),(1,'1  Partial'),(0,'0  No usable reporting')]]
fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.68,.53),frameon=False,fontsize=8,labelspacing=.9)
definitions=[('F1','Device configuration/integration'),('F2','Material/substrate composition'),('E1','Working strain range'),('E2','Sensitivity and strain interval'),('E3','Signal-quality descriptors'),('E4','Dynamic response/durability'),('R1','Environmental robustness'),('V1','On-body/garment reporting'),('V2','Comparator validation')]
for i,(code,label) in enumerate(definitions):
    fig.text(.69,.365-i*.026,code,fontsize=7.5,fontweight='bold');fig.text(.72,.365-i*.026,label,fontsize=7.5)
fig.savefig(OUT/'Figure6.png',dpi=300,facecolor='white')
fig.savefig(OUT/'Figure6.svg',facecolor='white')
