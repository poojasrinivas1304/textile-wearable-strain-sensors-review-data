from pathlib import Path
import json
BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'generated_figures'
OUT.mkdir(exist_ok=True)
DATA=json.loads((BASE/'data/analysis41.json').read_text())
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,Normalize
from matplotlib.patches import Rectangle
import runpy

layout=[('Fabrication', [('Fabricated samples', 'Q1'), ('Manufacturing batches', 'Q2'), ('Complete devices', 'Q3')]), ('Human evaluation', [('Participants', 'Q4'), ('Repeated sessions', 'Q5'), ('Inter-user transfer', 'Q13')]), ('Measurement and testing', [('Calibration', 'Q6'), ('External reference', 'Q7'), ('Statistical uncertainty', 'Q8'), ('Testing conditions', 'Q9'), ('Device reproducibility', 'Q10'), ('Stability/failure criteria', 'Q12')]), ('Wearable use and transparency', [('Environmental testing', 'Q11'), ('Fit, placement and pretension', 'Q14'), ('Electronics and power', 'Q15'), ('Data and code availability', 'Q16')])]
groups=[(g,[(name,*DATA['methodological_counts_score2_score1_score0'][code]) for name,code in items]) for g,items in layout]
plt.rcParams.update({'font.family':'Arial','font.size':8,'text.color':'#27343D','axes.labelcolor':'#252B30','xtick.color':'#46525A','ytick.color':'#46525A','svg.fonttype':'none'})
cmap=LinearSegmentedColormap.from_list('fig2_blue',['#FFFFFF','#DCEAF3','#A9CBE1','#447DA6']);norm=Normalize(0,100)
fig=plt.figure(figsize=(7.8,6.3),facecolor='white')
ax=fig.add_axes([.47,.075,.48,.75]);row=0
rename={'Complete devices':'Number of devices tested','Environmental testing':'Environmental standard/protocol'}
for group,items in groups:
    ax.text(-2.7,row,group,ha='left',va='center',fontsize=8.1,fontweight='bold',clip_on=False)
    ax.hlines(row,-.04,3,color='#B7C5CE',lw=.55,clip_on=False)
    row+=.77
    for name,*counts in items:
        ax.text(-.09,row,rename.get(name,name),ha='right',va='center',fontsize=8,clip_on=False)
        for j,n in enumerate(counts):
            pct=n/41*100
            ax.add_patch(Rectangle((j,row-.45),1,.90,facecolor=cmap(norm(pct)),edgecolor='#E2E8ED',lw=.4))
            ax.text(j+.5,row,f'{pct:.1f}%',ha='center',va='center',fontsize=8.7,color='white' if pct>=80 else '#253D4D')
        row+=.94
    row+=.12
for j,(heading,score) in enumerate([('Sufficiently explicit','Score 2'),('Partial','Score 1'),('No usable reporting','Score 0')]):
    ax.text(j+.5,-1.2,heading,ha='center',va='bottom',fontsize=8.3)
    ax.text(j+.5,-.65,score,ha='center',va='bottom',fontsize=7.1,color='#66747E')
ax.set(xlim=(0,3),ylim=(row-.4,-.4));ax.axis('off')
# A scale confined to the matrix width leaves the score headings unobstructed.
cax=fig.add_axes([.695,.939,.255,.012])
cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),cax=cax,orientation='horizontal',ticks=[0,50,100])
cb.ax.tick_params(labelsize=7,length=2,width=.4,pad=3);cb.outline.set_linewidth(.4);cb.outline.set_edgecolor('#9CAAB4')
fig.text(.47,.945,'Studies (%)',ha='left',va='center',fontsize=8)
fig.savefig(OUT/'Figure4.png',dpi=330,facecolor='white')
fig.savefig(OUT/'Figure4.svg',facecolor='white')
