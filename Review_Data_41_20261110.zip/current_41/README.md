# Textile wearable strain sensors review data

10 November 2026 version. This package contains the current 41-study review data and approved figures.

## Contents and interpretation

- `Supplementary_Data_41_20261014.xlsx` is the authoritative workbook. Its original filename is retained. It contains the screening ledger, extraction, rubrics, original ratings, consensus scores and source provenance.
- `E3_V1_Confirmed_Consensus_20261109.xlsx` records all 82 agreed E3/V1 ratings. Raiano E3=0 and V1=2 follow the additional supplementary-source check and reviewer confirmation. Original submitted blanks and differences remain distinguishable from consensus.
- The manuscript and supplementary PDF/LaTeX files reflect the final assessment. Copyrighted source papers, supplementary source PDFs, private messages and working drafts are excluded.
- `data/` contains CSV exports and `analysis41.json` from the current workbook. `independent_ratings.csv` preserves the original agreement inputs.
- `figures/` contains only the approved current assets. Internal filenames retain the earlier numbering: manuscript Figures 1–6 use Figure1, Figure2, Figure4, Figure5, Figure6 and Figure7 respectively. The removed construction illustration Figure3 is excluded. Figure7 is unchanged.
- `S11 quality evidence` column AA contains current methodological scores and AB their current basis. F/G/Z preserve historical decisions/statuses; AJ–AL preserve subsequent verification. Historical proposals are not adopted analysis scores.

All 369 reporting scores are numerical. E3 scores 0/1/2 total 4/8/29; V1 totals are 0/18/23. The methodological matrix contains 656 scores: 181 confirmed or verified and 475 retained Reviewer 2 assessments. The 123 later checks overlap 56 earlier confirmations and add 67 verifications to the earlier 114. These are distinct from the 82 E3/V1 consensus ratings.

The targeted reassessment consists of Reviewer 1 verification of assisted assessments, Reviewer 2 submissions and subsequent consensus. It is not represented as a new blinded independent rating series. Supporting documents were checked for 18 studies; source-specific coverage and remaining limitations are documented in the workbook.

## Reproduction

```sh
python -m pip install -r requirements.txt
python calculate_kappa.py --data data/independent_ratings.csv --output kappa_reproduced_check.json
python draw_figures.py
```

The quantitative plots are regenerated in `generated_figures/`. Arial is required to reproduce the approved typography; fonts are not distributed. Figure1 is the author-supplied final PRISMA image and Figure7 is the unchanged conceptual illustration; these two assets are supplied rather than regenerated.

Agreement statistics use the original 42-candidate eligibility exercise and 39 paired retained studies, never the current consensus scores. The historical labels "Figure 5 pooled" and "Figure 6 pooled" in the agreement CSV refer to the original readiness and reporting assessments. The script uses 10,000 study-cluster bootstrap samples, seed 2026, and omits undefined estimates. Readiness scores are encoded 0–4; shifting to 1–5 does not change quadratic-weighted kappa. Historical kappa and intervals are eligibility 0.787879 (0–1), readiness 0.772385 (0.604287–0.897773), and reporting 0.718120 (0.630941–0.798300).

Compile `main.tex` with pdfLaTeX, BibTeX and two further pdfLaTeX passes. Compile `Supplementary_Information.tex` twice with pdfLaTeX. The archive includes the required local class/style/bibliography files. `SHA256SUMS.txt` verifies all distributed files.

The manuscript title is Human validation of textile strain sensors for wearable monitoring. The revised abstract states retrospective eligibility refinement and reports comparator-validation and environmental-robustness results by eligibility route. A worked knee-angle example distinguishes within-participant prediction from transfer across wearers, sessions and repositioning. Screening exclusions are final reconciled decisions: complete paired pre-reconciliation decisions for all 793 exclusions could not be verified from available separate reviewer records. In workbook S2, current status is in column J and the historical register label is preserved in column L. The original 42-candidate eligibility exercise remains distinct.
