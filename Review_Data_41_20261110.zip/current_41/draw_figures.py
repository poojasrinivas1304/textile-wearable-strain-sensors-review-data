from pathlib import Path
import runpy
base=Path(__file__).resolve().parent
for number in [2,4,5,6]:
    runpy.run_path(str(base/f'plotting/figure{number}.py'),run_name='__main__')
print('Wrote quantitative figures to generated_figures/.')
