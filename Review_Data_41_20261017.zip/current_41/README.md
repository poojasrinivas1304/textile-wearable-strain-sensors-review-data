# Textile wearable strain sensors review data

17 October 2026 version.

## Contents

- `Supplementary_Data_41_20261014.xlsx`: final study inventory, extraction, definitions, scores, verification records and screening ledger. The filename retains its original identifier.
- `Supplementary_Information.tex` and `Supplementary_Information_41_20261014.pdf`: supplementary tables S1–S13, including S4a–S4c.
- `data/analysis41.json`: inputs for the quantitative figures.
- `data/independent_ratings.csv`: original independent ratings used for agreement analysis.
- `plotting/` and `figures/`: plotting scripts and quantitative figures.
- `SHA256SUMS.txt`: checksums of archive files.

## Reproduction

From this folder:

```sh
python -m pip install -r requirements.txt
python calculate_kappa.py --data data/independent_ratings.csv
python draw_figures.py
```

Agreement uses the original 42-candidate eligibility exercise and 39 paired retained studies for readiness/reporting, not all 41 included studies. Readiness levels 1–5 are encoded 0–4 in the CSV; this shift does not change quadratic-weighted kappa. The calculation uses 10,000 study-cluster bootstrap resamples per metric, seed 2026, and omits undefined estimates.

| Assessment | Paired studies | Kappa | 95% bootstrap interval |
| --- | ---: | ---: | --- |
| Eligibility | 42 | 0.787879 | 0–1 |
| Readiness axes | 39 | 0.772385 | 0.604287–0.897773 |
| Reporting items | 39 | 0.718120 | 0.630941–0.798300 |

`draw_figures.py` regenerates Figures 1, 2, 4, 5 and 6 in `generated_figures/`. Arial is required to match publication typography; fonts are not included. Conceptual Figures 3 and 7 are manuscript illustrations and are not regenerated here. Compile `Supplementary_Information.tex` twice with pdfLaTeX to generate the supplement.

Original reviewer ratings remain separate from subsequent verification and adjudication. Source uncertainties and study-specific verification status remain documented in the workbook. The distributions describe the selected evidence set; reporting scores do not certify clinical or regulatory readiness. Copyrighted source articles and private correspondence are not included.
