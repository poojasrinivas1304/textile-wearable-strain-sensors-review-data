"""Reproduce historical agreement from original independent ratings, never consensus.

Run: python calculate_kappa.py --data data/independent_ratings.csv
Requires numpy. Uses 10,000 study-cluster bootstrap samples per metric, seed2026.
The 41-study synthesis and 39-study original paired ratings are distinct cohorts.
"""
import argparse,csv,json,math,pathlib
import numpy as np

def kappa(rows,levels):
    matrix=np.zeros((levels,levels),dtype=float)
    for r in rows:matrix[int(r['reviewer1']),int(r['reviewer2'])]+=1
    n=matrix.sum()
    if n==0:return float('nan')
    expected=np.outer(matrix.sum(1),matrix.sum(0))/n
    weights=np.ones_like(matrix)-np.eye(levels) if levels==2 else np.fromfunction(lambda i,j:(i-j)**2/(levels-1)**2,(levels,levels))
    den=float((weights*expected).sum()/n)
    if np.isclose(den,0):return float('nan')
    return 1-float((weights*matrix).sum()/n)/den

def calculate(rows,levels):
    # Preserve the archived source-table study order for seeded sampling.
    ids=list(dict.fromkeys(r['record_id'] for r in rows));groups={i:[r for r in rows if r['record_id']==i] for i in ids}
    rng=np.random.default_rng(2026);est=[]
    for _ in range(10000):
        sample=[r for rid in rng.choice(ids,size=len(ids),replace=True) for r in groups[rid]]
        v=kappa(sample,levels)
        if math.isfinite(v):est.append(v)
    value=kappa(rows,levels)
    ci=np.percentile(est,[2.5,97.5]).tolist() if est else [None,None]
    return {'studies':len(ids),'paired_ratings':len(rows),'exact_matches':sum(r['reviewer1']==r['reviewer2'] for r in rows),'kappa':value if math.isfinite(value) else None,'ci95':ci,'valid_bootstrap':len(est)}

def main():
    p=argparse.ArgumentParser();p.add_argument('--data',default='data/independent_ratings.csv');p.add_argument('--output',default='kappa_reproduced.json');a=p.parse_args()
    rows=list(csv.DictReader(open(a.data,newline='',encoding='utf-8')))
    result={}
    for metric,levels in [('Eligibility',2),('Figure 5 pooled',5),('Figure 6 pooled',3)]:
        subset=[r for r in rows if r['metric']==metric]
        result[metric]=calculate(subset,levels)
    pathlib.Path(a.output).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
