"""Regenerate the current quantitative figures and PRISMA from archived data.
No eligibility decisions or ratings are changed by these scripts.
Requires numpy, matplotlib and the Arial font for the publication typography.
"""
from pathlib import Path
import subprocess, sys
root = Path(__file__).resolve().parent
for name in ["figure1.py", "figure2.py", "figure4.py", "figure56.py"]:
    subprocess.run([sys.executable, str(root / "plotting" / name)], check=True)
print("Generated Figures 1, 2, 4, 5 and 6 in generated_figures/.")
