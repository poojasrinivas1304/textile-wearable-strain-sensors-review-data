"""Figure 4 design preview; original scores and published assets are read-only."""
from pathlib import Path
import json, hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

BASE=Path(__file__).resolve().parents[1]
SOURCE=BASE/'data/analysis41.json'
OUT=BASE/'generated_figures'
OUT.mkdir(parents=True,exist_ok=True)
d=json.loads(SOURCE.read_text())
counts=d['counts']['quality']
groups=[
 ('Fabrication', [('Q1','Fabricated samples'),('Q2','Manufacturing batches'),('Q3','Complete devices')]),
 ('Human evaluation', [('Q4','Participants'),('Q5','Repeated sessions'),('Q13','Inter-user transfer')]),
 ('Measurement and testing', [('Q6','Calibration'),('Q7','External reference'),('Q8','Statistical uncertainty'),('Q9','Testing conditions'),('Q10','Device reproducibility'),('Q12','Stability / failure criteria')]),
 ('Wearable use and transparency', [('Q11','Environmental testing'),('Q14','Fit, placement and pretension'),('Q15','Electronics and power'),('Q16','Data and code availability')]),
]
assert {c for _,items in groups for c,_ in items}=={'Q'+str(i) for i in range(1,17)}
assert all(sum(counts[c])==41 for _,items in groups for c,_ in items)
palette={2:'#477E91',1:'#D5B47A',0:'#DDE2E6'}
ink='#263540'
plt.rcParams.update({'font.family':'Arial','font.size':9,'text.color':ink,
 'axes.labelcolor':ink,'xtick.color':'#53616B','svg.fonttype':'none','pdf.fonttype':42})
fig=plt.figure(figsize=(8.2,7.1),facecolor='white')
ax=fig.add_axes([.355,.105,.61,.81])
y=0; positions=[]; labels=[]; codes=[]; heads=[]
for heading,items in groups:
 heads.append((y,heading));y+=.72
 for c,label in items:
  positions.append(y);labels.append(label);codes.append(c);y+=1
 y+=.6
for yy,c in zip(positions,codes):
 left=0
 for score in [2,1,0]:
  n=counts[c][score];width=100*n/41
  ax.barh(yy,width,left=left,height=.62,color=palette[score],edgecolor='white',linewidth=.6,zorder=3)
  # Counts, rather than rounded percentages, expose the exact denominator.
  if n>=2:
   ax.text(left+width/2,yy,str(n),ha='center',va='center',fontsize=8,
           color='white' if score==2 else ink,zorder=4)
  left+=width
 assert abs(left-100)<1e-8
for yy,heading in heads:
 ax.text(-.55,yy,heading,transform=ax.get_yaxis_transform(),ha='left',va='center',
         fontsize=9,fontweight='bold',clip_on=False)
 ax.plot([0,100],[yy,yy],color='#D0D7DC',linewidth=.65,zorder=1)
ax.set_yticks(positions,labels,fontsize=9)
ax.tick_params(axis='y',length=0,pad=10)
ax.set_ylim(y-.55,-.35)
ax.set_xlim(0,100);ax.set_xticks([0,20,40,60,80,100])
ax.tick_params(axis='x',length=3,width=.6,labelsize=8.5)
ax.set_xlabel('Studies (%)',fontsize=9,labelpad=8)
ax.grid(axis='x',color='#E8ECEF',linewidth=.55,zorder=0)
ax.set_axisbelow(True)
for sp in ['top','right','left']:ax.spines[sp].set_visible(False)
ax.spines['bottom'].set_color('#A9B3BA');ax.spines['bottom'].set_linewidth(.6)
fig.legend(handles=[Patch(facecolor=palette[s],label=l) for s,l in
 [(2,'2: Clearly reported'),(1,'1: Partly reported'),(0,'0: Not reported')]],
 loc='upper center',bbox_to_anchor=(.51,.985),ncol=3,frameon=False,
 fontsize=9,handlelength=1.4,handleheight=.9,columnspacing=2)
fig.text(.355,.025,'All 41 studies; no not-applicable assignments. Numbers within bars are study counts.',
         fontsize=8,color='#53616B',ha='left')
fig.savefig(OUT/'Figure4.png',dpi=600,facecolor='white')
fig.savefig(OUT/'Figure4.svg',facecolor='white')
fig.savefig(OUT/'Figure4.pdf',facecolor='white')
fig.savefig(OUT/'Figure4_preview.png',dpi=180,facecolor='white')
plt.close(fig)
(OUT/'data_check.json').write_text(json.dumps({'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
 'n_studies':41,'codes_in_display_order':codes,'counts_0_1_2':{c:counts[c] for c in codes},
 'colors':palette,'title':None,'count_label_minimum':2,
 'original_master_and_published_figures_unchanged':True},indent=2))
print(OUT)
