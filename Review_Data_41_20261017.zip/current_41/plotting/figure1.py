"""Style-only redraw of the archived 41-study flow; no new screening decisions."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Rectangle
from matplotlib.font_manager import findfont

B=Path(__file__).resolve().parents[1]
O=B/'generated_figures';O.mkdir(parents=True,exist_ok=True)
blue='#477E91';ink='#263540';edge='#8799A3';sand='#D5B47A'
font_path=findfont('Arial',fallback_to_default=False)
plt.rcParams.update({'font.family':'Arial','font.size':9.5,'text.color':ink,'svg.fonttype':'none'})
fig=plt.figure(figsize=(8.2,10.5),facecolor='white');ax=fig.add_axes([0,0,1,1]);ax.set_xlim(0,100);ax.set_ylim(0,132);ax.axis('off')
boxes=[];texts=[]
def box(x,y,w,h,fill='white',stroke=edge,lw=.8):
 p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=.7',facecolor=fill,edgecolor=stroke,linewidth=lw,zorder=2);ax.add_patch(p)
 boxes.append((x,y,w,h))
 return p
def text(x,y,s,**kw):
 t=ax.text(x,y,s,va=kw.pop('va','center'),**kw);texts.append(t);return t
def arrow(x1,y1,x2,y2):
 ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=9,linewidth=.85,color='#637883',shrinkA=0,shrinkB=0,zorder=1))
def smallmain(y,title,count,h=9):
 box(12,y,39,h)
 text(31.5,y+h*.66,title,ha='center',fontsize=9.5,fontweight='bold')
 text(31.5,y+h*.30,f'(n = {count:,})',ha='center',fontsize=9.5)
def simple_right(y,title,count):
 box(60,y,39,9,fill='#FAF9F6')
 text(79.5,y+5.94,title,ha='center',fontsize=9.5,fontweight='bold')
 text(79.5,y+2.70,f'(n = {count:,})',ha='center',fontsize=9.5)

box(12,125,87,5,fill='#EDF3F5',stroke='#EDF3F5',lw=0)
text(55.5,127.5,'Identification of studies via databases',ha='center',fontsize=11.5,fontweight='bold',color=blue)
for y,h,label in [(94,28,'Identification'),(64,29,'Screening'),(21,42,'Eligibility'),(9,11,'Included')]:
 ax.add_patch(Rectangle((2,y),5,h,facecolor='#EDF3F5',edgecolor='none'))
 text(4.5,y+h/2,label,rotation=90,ha='center',fontsize=9.5,fontweight='bold',color=blue)

box(12,102,39,20)
text(14.2,119.1,'Records identified from databases',fontsize=9.5,fontweight='bold')
text(14.2,115.9,'(n = 3,684)',fontsize=9.5)
db=[('Scopus',1857),('Web of Science',1296),('PubMed',239),('Embase',184),('IEEE Xplore',108)]
for i,(label,n) in enumerate(db):
 yy=112.8-i*2.05;text(14.2,yy,label,fontsize=9.5);text(48.8,yy,f'{n:,}',ha='right',fontsize=9.5)
box(60,90,39,15,fill='#FAF9F6')
text(62.2,102.3,'Records removed before screening',fontsize=9.5,fontweight='bold')
text(62.2,99.5,'(n = 1,542)',fontsize=9.5)
text(62.2,95.8,'Duplicate records removed',fontsize=9.5);text(96.8,95.8,'1,482',ha='right',fontsize=9.5)
text(62.2,92.5,'Removed by publication type',fontsize=9.5);text(96.8,92.5,'60',ha='right',fontsize=9.5)
smallmain(84,'Records screened',2142)
simple_right(74.5,'Records excluded',1305)
smallmain(65,'Reports sought for retrieval',837)
simple_right(55.5,'Reports not retrieved',3)
smallmain(46,'Reports assessed for eligibility',834)

box(60,9,39,42,fill='#FAF9F6')
text(62.2,48.1,'Reports excluded (n = 793)',fontsize=9.5,fontweight='bold')
reasons=[('No tested textile or wearable\nintegration',297),('No participant-worn experiment',245),('Insufficient validation or\ndeployment evidence',135),('Human monitoring not central',68),('Strain or deformation not primary',38),('Non-strain-mediated human\noutcomes',2),('No quantitative human-wear result',2),('Not an eligible original article',4),('Duplicate or companion report',2)]
yy=44.5
reason_pairs=[]
for label,n in reasons:
 t=text(62.2,yy,label,fontsize=9,va='top',linespacing=1.25)
 fig.canvas.draw();renderer=fig.canvas.get_renderer()
 bounds=t.get_window_extent(renderer).transformed(ax.transData.inverted())
 number=text(96.8,(bounds.y0+bounds.y1)/2,str(n),ha='right',fontsize=9,va='center')
 reason_pairs.append((t,number))
 yy=bounds.y0-1.75
box(12,9,39,11,fill='#EDF3F5',stroke=blue,lw=1.1)
text(31.5,16.9,'Studies included in the review',ha='center',fontsize=9.5,fontweight='bold')
text(31.5,13.6,'(n = 41)',ha='center',fontsize=10,fontweight='bold',color=blue)
text(31.5,10.9,'Reports of included studies (n = 41)',ha='center',fontsize=9)
for bottom,top in [(102,93),(84,74),(65,55),(46,20)]:arrow(31.5,bottom,31.5,top)
for yy in [97.5,79,60,33]:arrow(31.5,yy,60,yy)
text(55.5,4.7,'Search completed 6 September 2026. Publication years 2015–2026.',ha='center',fontsize=8.5,color='#53616B')
assert sum(n for _,n in db)==3684
assert 3684-1482-60==2142 and 2142-1305==837 and 837-3==834 and 834-793==41
assert sum(n for _,n in reasons)==793
fig.canvas.draw();renderer=fig.canvas.get_renderer()
checked=0
for t in texts:
 x,y=t.get_position()
 containing=[b for b in boxes if b[0]<=x<=b[0]+b[2] and b[1]<=y<=b[1]+b[3]]
 if not containing:continue
 x0,y0,ww,hh=containing[-1]
 r=t.get_window_extent(renderer).transformed(ax.transData.inverted())
 assert r.x0>=x0+.5 and r.x1<=x0+ww-.5 and r.y0>=y0+.5 and r.y1<=y0+hh-.5, (t.get_text(),tuple(r.bounds),containing[-1])
 checked+=1
for label,number in reason_pairs:
 l=label.get_window_extent(renderer);n=number.get_window_extent(renderer)
 assert n.x0-l.x1>8, 'Insufficient gap between reason and count'
 assert abs((l.y0+l.y1-n.y0-n.y1)/2)<.1
print('Checked',checked,'boxed text elements; matched column widths; all reason counts vertically centred; font:',font_path)
for ext in ['png','svg','pdf']:fig.savefig(O/f'Figure1.{ext}',dpi=600,facecolor='white')
fig.savefig(O/'PRISMA_preview.png',dpi=170,facecolor='white');plt.close(fig)
(O/'data_check.json').write_text(json.dumps({'identified':3684,'duplicates':1482,'publication_types_removed':60,
 'screened':2142,'records_excluded':1305,'sought':837,'not_retrieved':3,'assessed':834,'reports_excluded':793,
 'included_studies':41,'included_reports':41,'database_counts':dict(db),'recorded_reasons':dict(reasons),
 'style_only':True,'historical_verification_limits_unchanged':True,'font_file':font_path,
 'boxed_text_fit_checks':checked,'equal_column_width':39,'reason_count_alignment_checked':True},indent=2))
print(O)
