"""Restyle Figure 2 without modifying its categories or study counts."""
from pathlib import Path
from collections import Counter
import json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

B=Path(__file__).resolve().parents[1]
S=B/'data/analysis41.json'
O=B/'generated_figures';O.mkdir(parents=True,exist_ok=True)
d=json.loads(S.read_text());years=Counter(r[4] for r in d['studies'])
arch=Counter(r[5] for r in d['categories']);mech=Counter(r[9] for r in d['categories'])
blue='#477E91';sand='#D5B47A';grey='#BDC7CE';ink='#263540'
plt.rcParams.update({'font.family':'Arial','font.size':9,'text.color':ink,'axes.labelcolor':ink,
 'xtick.color':'#53616B','ytick.color':ink,'svg.fonttype':'none','figure.facecolor':'white'})
fig=plt.figure(figsize=(9.4,6.8),facecolor='white')
a=fig.add_axes([.075,.60,.315,.29]);b=fig.add_axes([.70,.60,.26,.29])
c=fig.add_axes([.14,.14,.25,.31]);e=fig.add_axes([.70,.14,.26,.31])
for ax in [a,b,c,e]:
 ax.set_axisbelow(True)
 for k in ['top','right','left']:ax.spines[k].set_visible(False)
 ax.spines['bottom'].set_color('#A9B3BA');ax.spines['bottom'].set_linewidth(.6)
 ax.tick_params(axis='y',length=0,pad=7,labelsize=9)
 ax.tick_params(axis='x',length=3,width=.6,labelsize=8.5)
 ax.set_xlabel('Studies',fontsize=9,labelpad=7)
for ax in [b,c,e]:ax.grid(axis='x',color='#E8ECEF',linewidth=.6)
xx=list(range(2015,2027));vv=[years[x] for x in xx]
a.bar(xx,vv,color=blue,width=.69,zorder=3)
for x,v in zip(xx,vv):
 if v:a.text(x,v+.15,str(v),ha='center',va='bottom',fontsize=9)
a.set_xticks(xx,[str(x) for x in xx],rotation=55,ha='right',fontsize=8)
a.set_ylim(0,8);a.set_yticks([0,2,4,6,8]);a.set_xlim(2014.4,2026.65)
a.set_xlabel('');a.set_ylabel('Studies',fontsize=9,labelpad=7)
a.grid(axis='y',color='#E8ECEF',linewidth=.6)
ak=['Knitted sensing textile','Fibre/yarn/thread sensing element','Sensing fabric construction not determined','Woven sensing textile','Discrete/composite sensor mounted on garment','Embroidery/stitch-based sensing structure','Nonwoven/electrospun sensing mat']
al=['Knitted','Fibre / yarn / thread','Construction undetermined','Woven','Discrete/composite on garment','Embroidery / stitch','Nonwoven / electrospun']
av=[arch[k] for k in ak]
def horizontal(ax,labels,values,colors,limit,ticks):
 ax.barh(range(len(labels)),values,height=.59,color=colors,zorder=3)
 ax.set_yticks(range(len(labels)),labels)
 ax.invert_yaxis();ax.set_xlim(0,limit);ax.set_xticks(ticks)
 for i,v in enumerate(values):ax.text(v+limit*.018,i,str(v),va='center',ha='left',fontsize=9,color=ink)
horizontal(b,al,av,[blue,blue,grey,blue,blue,blue,blue],15,[0,5,10,15])
mk=['Resistive','Capacitive','Inductive'];mv=[mech[k] for k in mk]
horizontal(c,mk,mv,[blue,sand,grey],41,[0,10,20,30,40])
ap=['Movement / posture / gait','Respiration','Pulse / heartbeat','Speech / swallowing / facial','Robotic hand / HMI','Muscle contraction / force','Model-derived fatigue']
cols=[25,28,27,30,29,26,24];pv=[sum(r[k] for r in d['categories']) for k in cols]
horizontal(e,ap,pv,blue,41,[0,10,20,30,40]);e.set_xlabel('Studies (overlapping)',fontsize=9,labelpad=7)
for x,y,letter,label in [(.045,.955,'a','Publication profile'),(.47,.955,'b','Active sensing architecture'),(.045,.505,'c','Sensing mechanism'),(.47,.505,'d','Human applications')]:
 fig.text(x,y,letter,fontsize=11,fontweight='bold',ha='left',va='top')
 fig.text(x+.035,y,label,fontsize=10,fontweight='bold',ha='left',va='top')
fig.text(.075,.035,'Selected evidence set: 41 studies. Bar labels show study counts; application categories overlap.',fontsize=8,color='#53616B')
assert sum(vv)==sum(av)==sum(mv)==41
for ext in ['png','svg','pdf']:
 fig.savefig(O/f'Figure2.{ext}',dpi=600,facecolor='white')
fig.savefig(O/'Figure2_preview.png',dpi=180,facecolor='white');plt.close(fig)
(O/'data_check.json').write_text(json.dumps({'source_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),
 'years':dict(years),'architecture':dict(zip(ak,av)),'mechanism':dict(zip(mk,mv)),
 'overlapping_applications':dict(zip(ap,pv)),'counts_and_categories_unchanged':True},indent=2))
print(O)
